;------------------------------------------------------------------------------
; Flash.s
;
; Copy routine to move 8K of code from $2000 to $9000 with the proper timing for the EEPROM.
;
; We automatically detect which of the two EEPROM chips is present:
;      Batch 1 (200x) has AT28C64E: Byte-at-a-time programming (we delay 200us after each byte).
;      Batch 2 (2013) has AT28C64B: Has page-mode programming, so we need to do 64 bytes at a time
;                                   and then wait until the data reads back correctly (~10ms).
;                                   We may be able to just loop for each byte until it matches.
;------------------------------------------------------------------------------

.segment "EXEHDR"            ; just to keep the linker happy
.segment "STARTUP"           ; just to keep the linker happy

SPACE                =       $A0
CR                   =       $8D
ESC                  =       $9B

ByteInEEPROM         =       $AFD8         ; we try to modify this byte to identify the EEPROM type
SourceAddr           =       $2000
DestAddr             =       $9000
DataLength           =       $1FE0         ; copy 8K minus the last 32 bytes (the CF registers)

KEY_CONTROL          =       $D011
KEY_DATA             =       $D010
DSP_DATA             =       $D012
DSP_CONTROL          =       $D013

APPLE1_MON           =       $FF1F
BASIC_WARM           =       $E2B3

pSource              =       $A0
pDest                =       $A2
pEnd                 =       $A4
zpt1                 =       $F0          ; data at this location is saved/restored
MsgPointer           =       $F2          ; 2 bytes

StackBase            =       $100

    .org $1000

    cld
    ldx #$ff
    txs
    jsr DispString
    .byte CR
    .byte "FLASH UPDATE CFFA1 VER 1.1",CR,CR
    .byte "FLIP SWITCH S1-4 UP (ON) AND",CR
    .byte "PRESS SPACE TO BEGIN OR",CR
    .byte "ESC TO ABORT ",0

@key:
    jsr WaitForKey              ; wait for user to press any key
    cmp #SPACE
    beq @begin
    cmp #ESC
    bne @key
@aborted:
    jsr DispString
    .byte CR,CR,"ABORTED",CR,0
    jmp FlipSwitchAndExit

@begin:
    jsr DispCR
    jsr IdentifyEEPROM
    bcs @aborted

    jsr DispString
    .byte CR,CR
    .byte "BEGIN COPY",CR,0

    jsr SetUpSourceDestEnd
loop:
    ldy #0
    lda (pSource),y
    sta (pDest),y

    bit UsePageMode
    bpl @byteMode
; Page mode: If we stored the last byte of a 64-byte EEPROM page,
; then wait until it sticks (should take 10ms).
    lda pDest
    and #$3F
    cmp #$3F
    bne @nextByte
    lda (pSource),y
@waitForPageWrite:
    cmp (pDest),y
    bne @waitForPageWrite
    beq @nextByte

; Byte mode: Just wait for the byte to be written.
@byteMode:
    ldx #0
@waitForByteMode:
    cmp (pDest),y
    beq @nextByte
    dex
    bne @waitForByteMode
;   lda #$07 ; 200uS
;   jsr Wait

@nextByte:
    inc pSource
    bne @incDest
    inc pSource+1
@incDest:
    inc pDest
    bne @checkForEnd
    inc pDest+1
@checkForEnd:
    lda pDest
    cmp pEnd
    bne loop
    lda pDest+1
    cmp pEnd+1
    bne loop

    jsr DispString
    .byte "COPY COMPLETE.",CR
    .byte "BEGIN VERIFY:",CR,0
    jsr SetUpSourceDestEnd
    ldy #0
@verifyByte:
    lda (pDest),y
    cmp (pSource),y
    bne VerifyFailed

    inc pSource
    bne @1
    inc pSource+1
@1:
    inc pDest
    bne @2
    inc pDest+1
@2:
    lda pDest
    cmp pEnd
    bne @verifyByte
    lda pDest+1
    cmp pEnd+1
    bne @verifyByte

    jsr DispString
    .byte "VERIFY COMPLETE!",CR,0
    jmp FlipSwitchAndExit

VerifyFailed:
    pha

    jsr DispString
    .byte "VERIFY FAILED AT LOCATION:",0
    tya
    clc
    adc pDest
    pha
    lda pDest+1
    adc #0
    jsr DispByteWithDollarSign
    pla                       ; low byte of failed address
    jsr DispByte

    jsr DispString
    .byte " DATA:",0
    pla
    jsr DispByteWithDollarSign
    jsr DispCR
FlipSwitchAndExit:
    jsr DispString
    .byte "FLIP S1-4 BACK DOWN (OFF)",CR,0
    jmp APPLE1_MON

;------------------------------------------------------------------------------
; SetUpSourceDestEnd
;------------------------------------------------------------------------------
SetUpSourceDestEnd:
    lda #<SourceAddr
    sta pSource
    lda #>SourceAddr
    sta pSource+1

    lda #<DestAddr
    sta pDest
    lda #>DestAddr
    sta pDest+1

    lda #<(DestAddr+DataLength)
    sta pEnd
    lda #>(DestAddr+DataLength)
    sta pEnd+1
    rts

;------------------------------------------------------------------------------
; IdentifyEEPROM
;
; Returns SEC if error.
;------------------------------------------------------------------------------
IdentifyEEPROM:
    jsr DispString
    .byte CR,CR
    .byte "IDENTIFY EEPROM: ",0
    lda ByteInEEPROM
    sta OriginalByte
    eor #$01
    sta NewByte
    sta ByteInEEPROM
    lda NewByte         ; load the byte to ensure the page-mode chip starts the write cycle

;;; lda #$07            ; 200us at 1MHz
    lda #11             ; 453us at 1MHz
    jsr Wait

    lda ByteInEEPROM
    cmp OriginalByte
    beq @writeProtected

    cmp NewByte
    beq @byteModeEEPROM

;;; lda #$41            ; 11.19ms at 1MHz
    lda #90             ; 21ms at 1MHz (the page-mode chip should finish within 10ms)
    jsr Wait

    lda ByteInEEPROM
    cmp NewByte
    bne @error

@pageModeEEPROM:
    jsr DispString
    .byte "PAGE MODE",CR,0
    lda #$80
    bne @storeMode

@byteModeEEPROM:
    jsr DispString
    .byte "BYTE MODE",CR,0
    lda #0
@storeMode:
    sta UsePageMode     ; bit 7 = 64-byte page mode (AT28C64E)
    clc
    rts

@writeProtected:
    jsr DispString
    .byte "WRITE PROTECTED",CR,0
    sec
    rts

@error:
    jsr DispString
    .byte "ERROR",CR,0
    sec
    rts

OriginalByte:
    .byte 1
NewByte:
    .byte 1
UsePageMode:
    .byte 1

;------------------------------------------------------------------------------
;  Wait - Just like the Apple II WAIT routine.
;
; Input:
;       A = desired delay time, where Delay(us) = .5(5A^2 + 27A + 26)
;       or more usefully: A = (Delay[in uS]/2.5 + 2.09)^.5 - 2.7
;
; CPU Registers changed:  A, P
;------------------------------------------------------------------------------
Wait:
    sec
@Wait2:
    pha
@Wait3:
    sbc #1
    bne @Wait3
    pla
    sbc #1
    bne @Wait2
    rts

;------------------------------------------------------------------------------
; DispByte - Sends a Hex byte to the console
;
; Input:
;       A = Hex number to display
;
; CPU Registers changed:  A, P
;------------------------------------------------------------------------------
DispByteWithDollarSign:
    jsr DispString
    .byte "$",0
DispByte:
    pha
    lsr a
    lsr a
    lsr a
    lsr a
    jsr Nibble
    pla
Nibble:
    and #$0F
    ora #'0'
    cmp #'0'+10
    bcc @digit
    adc #6
@digit:
    bne DispChar   ; always taken

;------------------------------------------------------------------------------
; DispChar, DispCR - Sends a char to the Apple1 console
;
; Input:
;       A = Character to Send
; Ouput:
;
; ZeroPage Usage:
;       None
;
; CPU Registers changed:  Acc, P
;
; X and Y are preserved.
;------------------------------------------------------------------------------
DispCR:
    lda #CR
DispChar:
; Wait until display is ready
    bit DSP_DATA
    bmi DispChar
; Send character to display hardware
    sta DSP_DATA
    rts

;------------------------------------------------------------------------------
; DispString - Sends a String to the Apple1's console
;
; Input:
;       String immediately follows the JSR to this function
;       and is terminated with zero byte.
;
; ZeroPage Usage:
;       MsgPointer (2 bytes)
;
; CPU Registers changed:  P
;------------------------------------------------------------------------------
DispString:
    pha                          ; save the Acc reg
    txa
    pha                          ; save the X reg
    tya
    pha                          ; save the Y reg
    tsx                          ; put the stack pointer in X
    lda MsgPointer+1
    pha                          ; push zero page location on stack
    lda MsgPointer
    pha                          ; push zero page location on stack

    lda StackBase+4,x            ; determine the location of message to display
    clc
    adc #$01                     ; add 1 because JSR pushes the last byte of its
    sta MsgPointer               ; destination address on the stack

    lda StackBase+5,x
    adc #0
    sta MsgPointer+1

@1:
    ldy #0
    lda (MsgPointer),y
    beq @done
    jsr DispChar                 ; display message
    inc MsgPointer
    bne @1
    inc MsgPointer+1
    bne @1

@done:
    lda MsgPointer+1
    sta StackBase+5,x
    lda MsgPointer
    sta StackBase+4,x            ; fix up the return address on the stack.

    pla
    sta MsgPointer               ; restore zero page location
    pla
    sta MsgPointer+1             ; restore zero page location
    pla
    tay
    pla
    tax
    pla
    rts                          ;return to location after string's null.

;------------------------------------------------------------------------------
; WaitForKey - Wait until a key is pressed. Returns key stroke in Acc
; Input:
;      None
; Ouput:
;      Acc = ASCII value of key pressed
;
; X and Y are preserved.
;------------------------------------------------------------------------------
WaitForKey:
    lda KEY_CONTROL
    bpl WaitForKey
    lda KEY_DATA
    rts
