#include <stdio.h>
#include <unistd.h>

#define kMillisecond 1000 // milliseconds per microsecond

char Translate(char c)
{
	if (c == '\n')
		return '\r';
	return c;
}

int main(int argc, char* argv[])
{
	(void) argc;
	(void) argv;

	char buffer[128];
	while (fgets(buffer, sizeof(buffer), stdin))
	{
		char* p;
		for (p = buffer; *p != '\0'; ++p)
		{
			putchar(Translate(*p));
			fflush(stdout);
			usleep(17 * kMillisecond);
		}
		usleep(200 * kMillisecond);
	}
	return 0;
}
