;------------------------------------------------------------------------------
; CFFA for Apple 1 -- Minimal bootstrap code
;
; Once you get this code onto the Apple 1, it can read block 0 from the
; CompactFlash card to $0E00 and jump to it.
;------------------------------------------------------------------------------
.listbytes          unlimited
.segment            "EXEHDR"         ; just to keep the linker happy
.segment            "STARTUP"        ; just to keep the linker happy

;------------------------------------------------------------------------------
; Apple 1 monitor ROM
;------------------------------------------------------------------------------
APPLE1_MON          = $FF1F
PRBYTE              = $FFE5
COUT                = $FFEF

;------------------------------------------------------------------------------
; CFFA1 hardware registers
;------------------------------------------------------------------------------
IOBase              = $AFF0
IOBasePage          = $AF00
ATADevCtrl          = IOBase+6                  ; When writing
ATAAltStatus        = IOBase+6                  ; When reading
ATAData             = IOBase+8
ATAError            = IOBase+9                  ; When reading
ATAFeature          = IOBase+9                  ; When writing
ATASectorCnt        = IOBase+10
ATA_LBA07_00        = IOBase+11
ATA_LBA15_08        = IOBase+12
ATA_LBA23_16        = IOBase+13
ATA_LBA27_24        = IOBase+14
ATACommand          = IOBase+15                 ; When writing
ATAStatus           = IOBase+15                 ; When reading

;------------------------------------------------------------------------------
; ATA Commands Codes
;------------------------------------------------------------------------------
ATASetFeature       = $EF
ATACRead            = $20
Enable8BitTransfers = $01

;------------------------------------------------------------------------------
; Memory layout for this code, and the code it reads from the Compact Flash card.
;------------------------------------------------------------------------------
ThisCode            = $0D00
BootBlockCode       = $0E00

    .ORG ThisCode

    ldx #0
@next:
    ldy CommandTable,X
    lda CommandTable+1,X
    sta IOBasePage,Y
    inx
    inx
    cpy #<ATACommand
    bne @next
@wait:
    lda ATAStatus
    bmi @wait
    cpx #EndOfCommands-CommandTable
    bcc @next

    and  #$09
    cmp  #$01                    ; If DRQ=0 and ERR=1 a device error occured
    beq  ioError

    ldy  #0
@loop1:
    lda  ATAData
    sta  BootBlockCode,Y
    iny
    bne  @loop1
@loop2:
    lda  ATAData
    sta  BootBlockCode+$100,Y
    iny
    bne  @loop2

    lda #'B'+$80
    jsr COUT
    jmp BootBlockCode

ioError:
;   lda #'E'+$80
;   jsr COUT
    jmp APPLE1_MON

CommandTable:
    .byte <ATAFeature, Enable8BitTransfers
    .byte <ATA_LBA27_24, 0
    .byte <ATACommand, ATASetFeature
    .byte <ATA_LBA07_00, 0
    .byte <ATA_LBA15_08, 0
    .byte <ATA_LBA23_16, 0
    .byte <ATA_LBA27_24, $E0     ; Talk to the Master device and use LBA mode.
    .byte <ATASectorCnt, 1
    .byte <ATACommand, ATACRead
EndOfCommands:

;------------------------------------------------------------------------------
; END
;------------------------------------------------------------------------------
