;------------------------------------------------------------------------------
; CFFA for Apple 1 -- Booter
;
; This code lives on block 0 of a CF card.  The Bootstrap program loads us
; at $0E00 and jumps to us.
;------------------------------------------------------------------------------
.listbytes          unlimited
.segment            "EXEHDR"         ; just to keep the linker happy
.segment            "STARTUP"        ; just to keep the linker happy

;------------------------------------------------------------------------------
; Apple 1 monitor ROM
;------------------------------------------------------------------------------
APPLE1_MON          = $FF1F
PRBYTE              = $FFE5
COUT                = $FFEF

;------------------------------------------------------------------------------
; CFFA1 hardware registers
;------------------------------------------------------------------------------
IOBase              = $AFF0
IOBasePage          = $AF00
ATADevCtrl          = IOBase+6                  ; When writing
ATAAltStatus        = IOBase+6                  ; When reading
ATAData             = IOBase+8
ATAError            = IOBase+9                  ; When reading
ATAFeature          = IOBase+9                  ; When writing
ATASectorCnt        = IOBase+10
ATA_LBA07_00        = IOBase+11
ATA_LBA15_08        = IOBase+12
ATA_LBA23_16        = IOBase+13
ATA_LBA27_24        = IOBase+14
ATACommand          = IOBase+15                 ; When writing
ATAStatus           = IOBase+15                 ; When reading

;------------------------------------------------------------------------------
; ProDOS block interface locations
;------------------------------------------------------------------------------
ioBuffer            = $44                       ; 2 bytes
blockNumber         = $46                       ; 2 bytes

;------------------------------------------------------------------------------
; ATA Commands Codes
;------------------------------------------------------------------------------
ATASetFeature       = $EF
ATACRead            = $20
Enable8BitTransfers = $01

;------------------------------------------------------------------------------
; Entry point.  We got loaded at $0E00.  Read 24 more blocks at $1000..3FFF.
;------------------------------------------------------------------------------
ThisCode            = $0E00
CodeToLoad          = $1000
FirstBlock          = 1
LastBlock           = FirstBlock+23

    .ORG ThisCode
    ldx #$FF
    txs

    lda #Enable8BitTransfers
    sta ATAFeature
    lda #$00                         ; Drive=0
    sta ATA_LBA27_24                 ; Talk to the Master device and use LBA mode.
    lda #ATASetFeature
    sta ATACommand                   ; Issue the 8-bit feature command to the drive

    lda #>CodeToLoad
    ldx #<CodeToLoad
    sta ioBuffer+1
    stx ioBuffer

    lda #>FirstBlock
    ldx #<FirstBlock
    sta blockNumber+1
    stx blockNumber

@oneBlock:
    jsr ReadBlockAndAdvanceBuffer
    bcs @error
    inc blockNumber
    lda blockNumber
    cmp #LastBlock+1
    bcc @oneBlock
    jmp CodeToLoad

@error:
    lda #'E'+$80
    jsr COUT
    JMP APPLE1_MON

;------------------------------------------------------------------------------
; ReadBlock - Read a block from device into memory
;
; Input:
;        ioBuffer
;        blockNumber
;
; Output:
;       Carry flag: 0 = Okay, 1 = Error
;------------------------------------------------------------------------------
ReadBlockAndAdvanceBuffer:
   jsr IDEWaitReady

   lda blockNumber
   sta ATA_LBA07_00            ; store Low block # into LBA 0-7
   lda blockNumber+1
   sta ATA_LBA15_08            ; store High block # into LBA 15-8
   lda #0
   sta ATA_LBA23_16            ; store LBA bits 23-16
   lda #$E0                    ; 1, (LBA), 1, (Drive), LBA 27-24, where LBA=1, Drive=0
   sta ATA_LBA27_24            ; Talk to the Master device and use LBA mode.
   lda #1
   sta ATASectorCnt

   lda #ATACRead
   sta ATACommand              ; Issue the read command to the drive
   jsr IDEWaitReady            ; Wait for BUSY flag to clear

   lda ATAStatus               ; Check for error response from device
   and #$09
   cmp #$01                    ; If DRQ=0 and ERR=1 a device error occured
   bne @readyToRead
   sec
   rts

@readyToRead:
   ldy  #0
@rLoop1:
   lda ATAData
   sta (ioBuffer),y
   iny
   bne @rLoop1
   inc ioBuffer+1
@rLoop2:
   lda ATAData
   sta (ioBuffer),y
   iny
   bne @rLoop2
   inc ioBuffer+1
   clc
   rts

@error:
   sec
   rts

;------------------------------------------------------------------------------
; IDEWaitReady - Waits for BUSY flag to clear, and returns DRQ bit status
;
; Output:
;      Carry flag set if DRQ bit is on
;
; CPU Registers changed:  A, P
;------------------------------------------------------------------------------
IDEWaitReady:
   lda ATAStatus
   bmi IDEWaitReady             ; Wait for BUSY (bit 7) to be zero
   ror                          ; shift DRQ status bit into the Carry bit
   ror
   ror
   ror
   rts

;------------------------------------------------------------------------------
; END
;------------------------------------------------------------------------------
