.segment "EXEHDR"            ; just to keep the linker happy
.segment "STARTUP"           ; just to keep the linker happy

   .org $2000
   .include "CFFA1_API.s"

  ldx #CFFA1_Version
  jsr CFFA1_API
  ldx #CFFA1_DisplayError
  jsr CFFA1_API
  rts
