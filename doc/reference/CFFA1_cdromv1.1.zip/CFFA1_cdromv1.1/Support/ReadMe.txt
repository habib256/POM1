This utility may be used on a Windows PC to convert a binary file to an ASCII file ready for 
serial transfer to the Apple1. It is crude but easy to use. It is a command line tool only.

Typical usage:

c:\myApple1Stuff> bintoapple1 SomeApple1Program.bin 16 2000 > SomeApple1Program.hex

This would take a the file SomeApple1Program.bin and create a new ASCII file called SomeApple1Program.hex
with 16 bytes per line, starting at address $2000.

The ASCII file might look something like this:

2000:4D 5A 90 00 03 00 00 00 04 00 00 00 FF FF 00 00 
2010:B8 00 00 00 00 00 00 00 40 00 00 00 00 00 00 00 
2020:00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 
2030:00 00 00 00 00 00 00 00 00 00 00 00 E0 00 00 00 
2040:0E 1F BA 0E 00 B4 09 CD 21 B8 01 4C CD 21 54 68 
2050:69 73 20 70 72 6F 67 72 61 6D 20 63 61 6E 6E 6F 
2060:74 20 62 65 20 72 75 6E 20 69 6E 20 44 4F 53 20

